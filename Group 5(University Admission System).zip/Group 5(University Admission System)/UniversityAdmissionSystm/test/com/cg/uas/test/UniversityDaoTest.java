package com.cg.uas.test;
import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.dao.UserDAOImpl;
import com.capgemini.uas.exception.UASException;

public class UniversityDaoTest {
	static UniversityDAOImpl universityDao;
	static UserDAOImpl userDao;
	static Application application;
	static ApplicationStatus applicationStatus;
	
	@BeforeClass
	public static void initialize() {
		universityDao = new UniversityDAOImpl(); 
		 userDao=new UserDAOImpl();
		application = new Application();
		application = new Application();
		
		
}
	
	@Test
	public void testAddApplicationDetails() throws UASException{
		application.setApplicationId("50");
		application.setFullName("Rohit Rajpoot");
		application.setDateOfBirth("02-03-1996");
		application.setHighestQualification("12");
		application.setMarksObtained("90");
		application.setGoals("Gold Medal");
		application.setEmailID("gs@gmail.com");
		application.setScheduledProgramID("101");
		application.setStatus("open");
	}
	
	
}
