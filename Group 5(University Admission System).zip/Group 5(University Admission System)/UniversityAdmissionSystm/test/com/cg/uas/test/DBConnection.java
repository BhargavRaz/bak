package com.cg.uas.test;

import java.sql.Connection;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.exception.UASException;

public class DBConnection {
	
	static UniversityDAOImpl daoTest;
	static Connection dbCon;
	
	@BeforeClass
	public static void initialise(){
		daoTest = new UniversityDAOImpl();
  		dbCon = null;
	}
	@Before
	public void beforeEachTest(){
		System.out.println("-----Strating DBConnection Test Case-------\n");
	}
	
	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws UASException
	 **/
	
	@Test
	public void test() throws UASException {
		Connection dbCon = com.capgemini.uas.util.DBConnection.getInstance().getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daoTest = null;
		dbCon = null;
	}

}



