package com.cg.uas.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.ApplicantServiceImpl;
import com.capgemini.uas.service.IApplicantService;
import com.capgemini.uas.service.IMACService;
import com.capgemini.uas.service.IService;
import com.capgemini.uas.service.MACServiceImpl;
//import com.capgemini.uas.service.ServiceImpl;

public class ApplicantConsole {

	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	//static IService service = new ServiceImpl();
	static IMACService macservice = new MACServiceImpl();
	static IApplicantService applicantservice = new ApplicantServiceImpl();
	static Logger logger = Logger.getRootLogger();

	public void getApplicant() {
		PropertyConfigurator.configure("resource//log4j.properties");
		int applicationId;
		int programId;
		String ScheduledProgramId;
		String programName;
		ProgramsOffered offeredBean = null;
		ApplicationStatus statusBean = null;
		Application application = null;
		ProgramsScheduled scheduledBean = null;

		int choice = 0;
		int option;
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("-----------------------------------------");
			System.out.println(" 1 To See The Scheduled Programs List");
			System.out.println(" 2 To Fill The Form And Register");
			System.out.println(" 3 to Check Application Status ");
			System.out.println(" 4 to Logout  ");
			System.out.println("-----------------------------------------");
			try {

				choice = sc.nextInt();
				switch (choice) {

				case 1:
					
					//Printing The Scheduled Programs List
					System.out.println("List Of the Scheduled Programs: ");
					
					try {
						List<ProgramsScheduled> scheduledList = new ArrayList<>();
						scheduledList = applicantservice.getProgramSchedule();
						Iterator<ProgramsScheduled> i = scheduledList.iterator();
						
						for (ProgramsScheduled pg : scheduledList) {
							System.out.println("Program Id: "+ pg.getProgramId());
							System.out.println("Program Name: "+ pg.getProgramName());

						}

					}

					catch (UASException e) {
							System.out.println("Error  :" + e.getMessage());
					}
					break;

				case 2:
					
					//Inserting Applicant Details
					System.out.println("Enter The Details To Apply ");
					while (application == null) {

				try {
					
						application = populateApplicantDetails();
						applicantservice.validateDetails(application);
						applicationId = applicantservice.addApplicantDetails(application);
						System.out.println("Application details has been registered successfully");
						System.out.println("Application ID Is: "+ applicationId);
						
					}
				catch (IOException | UASException e) 
				{
					e.printStackTrace();
				}

			}
					 getApplicant();
					break;
					
			

				case 3:
					
				//Fetching Application Details
					System.out.println("Enter Application Id: ");
					applicationId = sc.nextInt();
					statusBean = getApplicationDetails(applicationId);

					if (statusBean != null) {
						System.out.println("Application ID : "
								+ statusBean.getApplicationId());
						System.out.println("Name  : "
								+ statusBean.getFullName());
						System.out.println("Date Of Birth(dd-mm-yyyy): "
								+ statusBean.getDateOfBirth());
						System.out.println("Scheduled Program Id: "
								+ statusBean.getScheduledProgramId());
						System.out.println("Status: " + statusBean.getStatus());
						System.out.println("Date Of Interview: " + statusBean.getDateOfInterview());
					} 
					else {
						System.err.println("There are no Applicant with this id "+ applicationId);
					}
				
		//Going back To Main 
				case 4:
					System.out.println("Applicant logged out");
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
		// End of switch statement

			} catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
		} while (choice != 4);

	}
	
	
//Populate Function To Insert Application Details
	private static Application populateApplicantDetails()
			throws IOException {

		Application application = new Application();
		System.out.println("-----------------------------------------");
		System.out.println("\n Enter The Details of Applicant");

		System.out.println("Enter Name: ");
		application.setFullName(br.readLine());

		System.out.println("Enter Email Id ");
		application.setEmailID(br.readLine());

		System.out.println("Enter date of Birth(dd-mm-yyyy)");
		application.setDateOfBirth(br.readLine());

		System.out.println("Enter Program Id ");
		application.setScheduledProgramID(br.readLine());

		System.out.println("Enter Highest Qualification");
		application.setHighestQualification(br.readLine());

		System.out.println("Enter Marks Details ");
		application.setMarksObtained(br.readLine());

		System.out.println("Enter Goals ");
		application.setGoals(br.readLine());

		System.out.println("Enter Status(Should be 'open') ");
		application.setStatus(br.readLine());
		
		System.out.println("-----------------------------------------");
		 
		//populateApplicantDetails();
		return application;
	}

	private static ApplicationStatus getApplicationDetails(int applicationId) {
		ApplicationStatus statusBean = null;
		try {
			statusBean = macservice.getApplicationStatus(applicationId);
		} catch (UASException e) {
			logger.error("exception occured ", e);
			System.out.println("ERROR : " + e.getMessage());

		}
		return statusBean;
	}
}
