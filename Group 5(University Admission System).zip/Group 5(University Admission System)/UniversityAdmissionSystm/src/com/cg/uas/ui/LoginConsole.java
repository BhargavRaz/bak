package com.cg.uas.ui;


import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IService;
import com.capgemini.uas.service.IUserService;
//import com.capgemini.uas.service.ServiceImpl;
import com.capgemini.uas.service.UserServiceImpl;

public class LoginConsole {
	static BufferedReader br = new BufferedReader(new InputStreamReader(
			System.in));
	//static IService service = new ServiceImpl();
	static Scanner sc = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	public void getLoginDetails() {
		PropertyConfigurator.configure("resource//log4j.properties");
		int applicationId;
		int programId;
		String ScheduledProgramId;
		String programName;
		ProgramsOffered offeredBean = null;
		ApplicationStatus statusBean = null;
		Application application = null;
		ProgramsScheduled scheduledBean = null;

		int option = 0;
		int choice = 0;
		System.out.println("---------------------------------");
		System.out.println("[1]Login [2]Exit");
		System.out.println("---------------------------------");
		choice = sc.nextInt();
		int loginAttempts = 0;
		while (choice != 2 && loginAttempts <= 3) 
		{
			if (choice == 1)
			{
				IUserService userService = new UserServiceImpl();
				
				System.out.print("USERNAME? ");
				String userName = sc.next();
				
				System.out.print("PASSWORD?");
				String password = sc.next();
				loginAttempts++;
				
				try {
					String role = userService.getRole(userName, password);
					System.out.println(role);
					if ("admin".equals(role)) {
						AdminConsole ac = new AdminConsole();
						ac.getAdminFunction();

					} else {
						MACConsole mc = new MACConsole();
						mc.getMac();

					}
				} catch (UASException e) {
					System.err.println("please provide correct username and password");
				}
			}

		}
	}
}
