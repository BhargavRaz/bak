package com.capgemini.uas.service;

import com.capgemini.uas.bean.User;
import com.capgemini.uas.dao.IUserDAO;
import com.capgemini.uas.dao.UserDAOImpl;
import com.capgemini.uas.exception.UASException;

public class UserServiceImpl implements IUserService {

	private IUserDAO dao = new UserDAOImpl();

	@Override
	public String getRole(String unm, String pwd) throws UASException {
		String role = null;
		User user = dao.getUserByName(unm);
		if (user == null)
			throw new UASException("No Such UserName");
		else if (!pwd.equals(user.getPassword()))
			throw new UASException("Password Mismatch");
		else
			role = user.getRole();
		return role;
	}

}
