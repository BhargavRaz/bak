package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;

public interface IApplicantService {
	
	public List<ProgramsScheduled> getProgramSchedule() throws UASException;

	int addApplicantDetails(Application application) throws UASException;
	
	public void validateDetails(Application bean) throws UASException;

}
