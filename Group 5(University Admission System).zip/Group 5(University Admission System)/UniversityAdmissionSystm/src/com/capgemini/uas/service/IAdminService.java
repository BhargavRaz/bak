package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.exception.UASException;

public interface IAdminService {

	public int deleteOfferedProgram(String programName) throws UASException;

	public int updateProgramsOffered(ProgramsOffered programsOffered)
			throws UASException;

	public int addToSchedule(ProgramsScheduled scheduledBean)
			throws UASException;
	
	public int deleteScheduledPgm(String pgmId) throws UASException;
	
	public List<ProgramsScheduled> getProgramScheduledByDate(
			String startDate, String endDate) throws UASException;

	public int addToOffered(ProgramsOffered offeredBean)
			throws UASException;

	public void validatePrograms(ProgramsScheduled bean)
				throws UASException;

	
}
