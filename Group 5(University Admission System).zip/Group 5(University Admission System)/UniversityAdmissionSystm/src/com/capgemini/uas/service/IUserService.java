package com.capgemini.uas.service;

import com.capgemini.uas.exception.UASException;

public interface IUserService {
	String getRole(String unm, String pwd) throws UASException;
}
