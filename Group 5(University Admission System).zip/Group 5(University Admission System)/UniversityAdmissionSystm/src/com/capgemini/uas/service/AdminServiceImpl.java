package com.capgemini.uas.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.dao.IUniversityDAO;
import com.capgemini.uas.dao.UniversityDAOImpl;
import com.capgemini.uas.exception.UASException;

public class AdminServiceImpl implements IAdminService {
	
	Logger logger1 = Logger.getRootLogger();

	@Override
	public int deleteOfferedProgram(String programName) throws UASException {
		IUniversityDAO universityDAO = new UniversityDAOImpl();
		return universityDAO.deleteOfferedProgram(programName);
	}

	@Override
	public int updateProgramsOffered(ProgramsOffered programsOffered)
			throws UASException {
		IUniversityDAO universityDAO = new UniversityDAOImpl();
		return universityDAO.updateProgramsOffered(programsOffered);
	}

	@Override
	public int addToSchedule(ProgramsScheduled scheduledBean)
			throws UASException {
		int noOfUpdates = 0;
		IUniversityDAO universityDAO = new UniversityDAOImpl();
		return universityDAO.addToSchedule(scheduledBean);
	}

	@Override
	public int deleteScheduledPgm(String pgmId) throws UASException {
		IUniversityDAO universityDAO = new UniversityDAOImpl();
		return universityDAO.deleteScheduledPgm(pgmId);
	}

	@Override
	public List<ProgramsScheduled> getProgramScheduledByDate(String startDate,
			String endDate) throws UASException {
		//System.out.println("in service");
		IUniversityDAO universityDAO = new UniversityDAOImpl();
		
		List<ProgramsScheduled> plist=new ArrayList<ProgramsScheduled>();
	  plist= universityDAO.getProgramScheduledByDate(startDate, endDate);
	  return plist;
	}

	@Override
	public int addToOffered(ProgramsOffered offeredBean) throws UASException {
		IUniversityDAO universityDAO = new UniversityDAOImpl();

		return universityDAO.addToOffered(offeredBean);
	}
	
	Logger logger = Logger.getRootLogger();

	@Override
	public void validatePrograms(ProgramsScheduled bean) throws UASException {
		List<String> vError = new ArrayList<String>();
		logger.info("Validating  details");

		Pattern applLocation = Pattern.compile("[A-Za-z]+{20}");
		Matcher strMatch = applLocation.matcher(bean.getLocation());

		Pattern applName = Pattern.compile("^[A-Za-z]+{20}$");
		Matcher nameMatch = applName.matcher(bean.getProgramName());

		Pattern applsession = Pattern.compile("^[0-2]{1}[0-9]{1}$");
		Matcher sessionMatch = applsession.matcher(bean.getSessionPerWeek());

		if (!(strMatch.matches())) {

			vError.add("Location should contain alphabets only");
			logger.error("location error");

		} else if (bean.getLocation() == " ") {
			logger.error(new UASException("should not be empty"));
			logger.error(" location error");

		}

		if (!(nameMatch.matches())) {

			vError.add("name should contain alphabets only");
			logger.error("name error");

		} else if (bean.getProgramName() == "") {
			logger.error(new UASException("should not be empty"));
			logger.error(" name error");

		}

		if (!(sessionMatch.matches())) {

			vError.add("Number of sessions should be <30 and more than 10");
			logger.error("session error");

		} else if (bean.getSessionPerWeek() == "") {
			logger.error(new UASException("should not be empty"));
			logger.error("session error");
		}

		if (!(vError.isEmpty())) {
			System.out.println(vError + " ");

			throw new UASException(vError + " ");
		
	}
	}

}
