package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.Application;
import com.capgemini.uas.bean.ApplicationStatus;
import com.capgemini.uas.bean.RetrieveAllDetails;
import com.capgemini.uas.bean.ProgramsOffered;
import com.capgemini.uas.bean.ProgramsScheduled;
import com.capgemini.uas.bean.ScheduledProgramID;
import com.capgemini.uas.exception.UASException;

public interface IService {

	//public List<ProgramsScheduled> getProgramSchedule() throws UASException;

	//int addApplicantDetails(Application application) throws UASException;

	//List<Application> getAllApplications(int scheduledPgmId)
		//	throws UASException;

	//int updateStatus(Application application) throws UASException;

	//List<ScheduledProgramID> getScheduledProgramIdName()
		//	throws UASException;

//	public List<ProgramsOffered> getProgramsOffered() throws UASException;



	//public List<RetrieveAllDetails> getProgramDetails() throws UASException;

	

	//public ApplicationStatus getApplicationStatus(Integer applicationId)
		//	throws UASException;

	

	//public void validateDetails(Application bean) throws UASException;

	
}
